package veterinaria.repository;

import java.util.List;

import veterinaria.model.Mascota;


public interface IMascotaRepo {
	List<Mascota> getListado();
}
