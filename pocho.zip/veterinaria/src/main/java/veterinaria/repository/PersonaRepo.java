package veterinaria.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import veterinaria.model.Persona;


@Profile("!elretraso")
@Repository
public class PersonaRepo implements IPersonaRepo{
	
	static List<Persona> listado = new ArrayList<Persona>();
	
	static {
		listado.add(new Persona(1, "12345678A", "Pepe", new ArrayList<Integer>()));
		listado.add(new Persona(2, "87654321M", "Manolo", new ArrayList<Integer>()));
	}
	
	@Override
	public List<Persona> getListado() {
		return listado;
	}
	
}
