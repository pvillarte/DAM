package veterinaria.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import veterinaria.model.Mascota;
import veterinaria.model.Persona;


@Profile("elretraso")
@Repository
public class PersonaEspecialRepo implements IPersonaRepo{
	
	static List<Persona> listado = new ArrayList<Persona>();

	
	static {
		listado.add(new Persona(1, "12345678A", "Manolin", new ArrayList<Integer>()));
		listado.add(new Persona(2, "87565331M", "Peponaso", new ArrayList<Integer>()));
	}
	
	@Override
	public List<Persona> getListado() {
		return listado;
	}
	
}
