package veterinaria.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import veterinaria.model.Persona;
import veterinaria.service.IMascotaService;
import veterinaria.service.IPersonaService;

@Controller
public class PersonaController {
	
	@Autowired
	IPersonaService service;
	@Autowired
	IMascotaService serviceMascotas;
	
	@GetMapping("/persona")
	public ModelAndView index(ModelAndView model) {
		model.addObject("personas", service.getAll());
		model.setViewName("persona/index");
		return model;
	}
	
	@GetMapping("/persona/details/{id}")
	public ModelAndView details(@PathVariable("id") int id, ModelAndView model) {
		model.addObject("persona", service.getById(id));
		model.addObject("mascotas", serviceMascotas.getByAmo(id));
		model.setViewName("persona/details");
		return model;
	}
	
	@GetMapping("/persona/update/{id}")
	public ModelAndView update(@PathVariable("id") int id, ModelAndView model) {
		model.addObject("persona", service.getById(id));
		model.setViewName("persona/update");
		return model;
	}
	
	@PostMapping("/persona/update")
	public String update(@ModelAttribute Persona personaUpdated) {
		service.getById(personaUpdated.getId()).setNombre(personaUpdated.getNombre());
		service.getById(personaUpdated.getId()).setDni(personaUpdated.getDni());
		return "redirect:/persona";
	}
	
	
	
	
}
